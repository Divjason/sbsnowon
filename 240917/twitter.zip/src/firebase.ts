import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAJAM43k_ac4O1hJA0kMEgvwBY7cLBn1Po",
  authDomain: "twitter-reloaded01.firebaseapp.com",
  projectId: "twitter-reloaded01",
  storageBucket: "twitter-reloaded01.appspot.com",
  messagingSenderId: "285253852087",
  appId: "1:285253852087:web:2e6906660042659f816632",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
