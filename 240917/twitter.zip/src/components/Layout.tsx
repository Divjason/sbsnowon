import React from "react";
import { Outlet } from "react-router-dom";

const layout = () => {
  return (
    <>
      <h2>Layout</h2>
      <Outlet />
    </>
  );
};

export default layout;
