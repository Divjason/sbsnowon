// Navi
const liTags = document.querySelectorAll(".navi > li");
liTags.forEach((li) => {
  li.addEventListener("mouseover", () => {
    const submenu = li.querySelector(".submenu");
    submenu.style.display = "block";
  });

  li.addEventListener("mouseout", () => {
    const submenu = li.querySelector(".submenu");
    submenu.style.display = "none";
  });
});

// Slide
const slides = document.querySelectorAll(".imgslide a");

// 첫번째 슬라이드 부터 출력될 수 있도록 하는 반복문
slides.forEach((slide, index) => {
  if(index > 0) {
    slide.style.display = "none";
  };
});

let currentIndex = 0;
setInterval(() => {
  slides[currentIndex].style.opacity = 0;
  slides[currentIndex].style.transition = "opacity 1s";

  currentIndex = (currentIndex + 1) % slides.length;

  slides[currentIndex].style.display = "block";
  slides[currentIndex].style.opacity = 0;
  slides[currentIndex].style.transition = "opacity 1s";

  setTimeout(() => {
    slides[currentIndex].style.opacity = 1;
  }, 10);
}, 3000);