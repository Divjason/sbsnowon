import React, { useState } from "react";
import styled from "styled-components";
import { ITweet } from "./TimeLine";
import { auth, db, storage } from "../firebase";
import { deleteDoc, doc, getDoc, updateDoc } from "firebase/firestore";
import {
  deleteObject,
  getDownloadURL,
  ref,
  StorageError,
  StorageErrorCode,
  uploadBytes,
  uploadBytesResumable,
} from "firebase/storage";

const Wrapper = styled.div`
  display: grid;
  grid-template-columns: 3fr 1fr;
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 15px;
  padding: 20px;
`;

const Column = styled.div``;

const Photo = styled.img`
  width: 100%;
  height: 100%;
  border-radius: 15px;
`;

const Video = styled.video`
  width: 100%;
  height: 100%;
  border-radius: 15px;
`;

const Username = styled.span`
  font-size: 15px;
  font-weight: 600;
`;

const Payload = styled.p`
  margin: 10px 0;
  font-size: 18px;
`;

const DeleteButton = styled.button`
  background: #ff6347;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  cursor: pointer;
`;

// 수정폼 활성화
const EditButton = styled.button`
  background-color: #7f8689;
  color: white;
  font-weight: 600;
  border: 0;
  font-size: 12px;
  padding: 5px 10px;
  text-transform: uppercase;
  border-radius: 5px;
  cursor: pointer;
`;

// 수정폼
const EditTweetFormTextArea = styled.textarea`
  background-color: black;
  border-radius: 10px;
  color: white;
  font-size: 16px;
  width: 100%;
  padding: 10px;
  margin: 10px 0;
  resize: none;
  &::placeholder {
    font-size: 16px;
  }
  &:focus {
    outline: none;
  }
`;

const EditorColumns = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  gap: 10px;
`;

// 수정버튼
const UpdateButton = styled.button`
  background-color: #1d9bf0;
  color: white;
  font-weight: 600;
  border: 0;
  font-size: 12px;
  padding: 5px 10px;
  text-transform: uppercase;
  border-radius: 5px;
  cursor: pointer;
`;

// 수정취소버튼
const CancelButton = styled.button`
  background-color: #7f8689;
  color: white;
  font-weight: 600;
  border: 0;
  font-size: 12px;
  padding: 5px 10px;
  text-transform: uppercase;
  border-radius: 5px;
  margin: 0px 10px;
  cursor: pointer;
`;

// 이미지 수정 버튼
const SetImageButton = styled.label`
  color: white;
  cursor: pointer;
  &:hover {
    color: #1d9bf0;
  }
  svg {
    width: 24px;
  }
`;

const SetImageButtonInput = styled.input`
  display: none;
`;

// export interface IEditedTweetData {
//   tweet: string; // 업데이트된 트윗내용
//   photo?: string; // 업데이트된 사진 URL
// }

const Tweet = ({ username, photo, video, tweet, userId, id }: ITweet) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTweet, setEditedTweet] = useState(tweet);
  const [editedPhoto, setEditedPhoto] = useState<File | null>(null);

  const user = auth.currentUser;

  const onChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setEditedTweet(e.target.value);
  };
  const handleCancel = () => {
    // isEditing 값: true -> false 로 변경
    setIsEditing(false);
  };
  const handleEdit = async () => {
    // isEditing 값: false -> true 로 변경
    setIsEditing(true);
  };
  const onUpdate = async () => {
    try {
      if (user?.uid !== userId) return;

      // 트윗 문서를 불러와서 문서가 존재하는지 확인
      const tweetDoc = await getDoc(doc(db, "tweets01", id));

      if (!tweetDoc.exists()) {
        throw new Error("Document does not exist");
      }

      const tweetData = tweetDoc.data(); // 문서 데이터 가져오기
      const existingFileType = tweetData?.fileType || null; // fileType이 없을 경우 null

      console.log(existingFileType);

      if (editedPhoto) {
        // 새로 업로드하는 파일의 타입을 확인
        const newFileType = editedPhoto.type.startsWith("image/")
          ? "image"
          : "video";

        // 기존 파일과 새로 업로드하는 파일의 타입이 다른 경우 업로드 차단
        if (existingFileType && existingFileType !== newFileType) {
          alert(
            "You can only upload the same type of content (image or video)."
          );
          return;
        }

        // 트위터 + 사진 변경
        // 트위터 주소 참조
        const locationRef = ref(storage, `tweets01/${user.uid}/${id}`);

        const uploadTask = uploadBytesResumable(locationRef, editedPhoto);
        if (editedPhoto.size >= 5 * 1024 * 1024) {
          // 사진크기가 5MB 이상이면 업로드를 진행하지 않고 예외 발생
          // 업로드 취소
          uploadTask.cancel();
          throw new StorageError(
            StorageErrorCode.CANCELED,
            "file size is over 5MB"
          );
        }

        // 새로운 사진을 storage에 등록
        const result = await uploadBytes(locationRef, editedPhoto);
        const url = await getDownloadURL(result.ref);
        // 문서 업데이트 (파일의 URL과 타입 저장)
        await updateDoc(doc(db, "tweets01", id), {
          tweet: editedTweet,
          photo: newFileType === "image" ? url : "",
          video: newFileType === "video" ? url : "",
          fileType: newFileType, // 새로운 파일 타입 저장
        });
      } else {
        // 트위터 내용만 수정
        await updateDoc(doc(db, "tweets01", id), { tweet: editedTweet });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsEditing(false);
    }
  };

  const onClickSetImageButton = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { files } = e.target;
    if (!user) return;
    if (files && files.length === 1) {
      setEditedPhoto(files[0]);
    }
  };

  const onDelete = async () => {
    const ok = confirm("Are you sure you want to delete this tweet?");
    if (!ok || user?.uid !== userId) return;
    try {
      await deleteDoc(doc(db, "tweets01", id));
      if (photo) {
        const photoRef = ref(storage, `tweets01/${user.uid}/${id}`);
        await deleteObject(photoRef);
      }
    } catch (e) {
      console.log(e);
    } finally {
    }
  };
  return (
    <Wrapper>
      <Column>
        <Username>{username}</Username>
        {isEditing ? (
          <EditTweetFormTextArea
            rows={5}
            maxLength={180}
            onChange={onChange}
            placeholder={tweet}
            value={editedTweet}
          ></EditTweetFormTextArea>
        ) : (
          <Payload>{tweet}</Payload>
        )}
        <EditorColumns>
          {user?.uid === userId ? (
            <>
              {isEditing ? (
                <>
                  <CancelButton onClick={handleCancel}>Cancel</CancelButton>
                  <UpdateButton onClick={onUpdate}>Update</UpdateButton>
                  <SetImageButton htmlFor="edit-photo">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="size-6"
                    >
                      <path
                        fillRule="evenodd"
                        d="M1.5 6a2.25 2.25 0 0 1 2.25-2.25h16.5A2.25 2.25 0 0 1 22.5 6v12a2.25 2.25 0 0 1-2.25 2.25H3.75A2.25 2.25 0 0 1 1.5 18V6ZM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0 0 21 18v-1.94l-2.69-2.689a1.5 1.5 0 0 0-2.12 0l-.88.879.97.97a.75.75 0 1 1-1.06 1.06l-5.16-5.159a1.5 1.5 0 0 0-2.12 0L3 16.061Zm10.125-7.81a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <SetImageButtonInput
                      id="edit-photo"
                      type="file"
                      accept="image/*"
                      onChange={onClickSetImageButton}
                    />
                  </SetImageButton>
                </>
              ) : (
                <EditButton onClick={handleEdit}>Edit</EditButton>
              )}
            </>
          ) : null}
          {
            // 삭제 버튼
            user?.uid === userId ? (
              <DeleteButton onClick={onDelete}>Delete</DeleteButton>
            ) : null
          }
        </EditorColumns>
      </Column>
      {photo ? (
        <Column>
          <Photo src={photo} />
        </Column>
      ) : null}
      {video ? (
        <Column>
          <Video src={video} />
        </Column>
      ) : null}
    </Wrapper>
  );
};

export default Tweet;
