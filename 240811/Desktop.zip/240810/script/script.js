// Menu
const naviLIs = document.querySelectorAll(".navi > li");
naviLIs.forEach((naviLI) => {
    naviLI.addEventListener("mouseover", () => {
        const submenus = document.querySelectorAll(".submenu");
        const menuBg = document.querySelector("#menu_bg");
        submenus.forEach((submenu) => {
            submenu.style.opacity = "1";
            submenu.style.maxHeight = "160px";
            menuBg.style.opacity = "1";
            menuBg.style.maxHeight = "160px";
        });
    });

    naviLI.addEventListener("mouseout", () => {
        const submenus = document.querySelectorAll(".submenu");
        const menuBg = document.querySelector("#menu_bg");
        submenus.forEach((submenu) => {
            submenu.style.opacity = "0";
            submenu.style.maxHeight = "0";
            menuBg.style.opacity = "0";
            menuBg.style.maxHeight = "0";
        });
    });
});

// Slide 
const slides = document.querySelectorAll(".imgslide a");
slides.forEach((slide, index) => {
    if(index > 0) {
        slide.style.display = "none";
    }
});

let currentIndex = 0;
setInterval(() => {
    slides[currentIndex].style.opacity = 0;
    slides[currentIndex].style.transition = "opacity 1s";

    currentIndex = (currentIndex + 1) % slides.length;

    slides[currentIndex].style.display = "block";
    slides[currentIndex].style.opacity = 0;
    slides[currentIndex].style.transition = "opacity 1s";
    setTimeout(() => {
        slides[currentIndex].style.opacity = 1;
    }, 10)
}, 3000);

// Modal
const noticeList = document.querySelector(".notice li:first-child");
const closeBtn = document.querySelector(".btn");

noticeList.addEventListener("click", () => {
    document.querySelector("#modal").classList.add("active");
})

closeBtn.addEventListener("click", () => {
    document.querySelector("#modal").classList.remove("active");
})
