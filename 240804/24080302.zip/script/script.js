// Nav Event
const naviLIs = document.querySelectorAll(".navi > li");
naviLIs.forEach((naviLI) => {
  const submenus = document.querySelectorAll(".submenu");
  naviLI.addEventListener("mouseover", () => {
    submenus.forEach((submenu) => {
      submenu.style.opacity = "1";
      submenu.style.maxHeight = "160px";
    });
  });

  naviLI.addEventListener("mouseout", () => {
    submenus.forEach((submenu) => {
      submenu.style.opacity = "0";
      submenu.style.maxHeight = "0";
    })
  })
});

// Slide Event
const slideShow = () => {
  const slideList = document.querySelector(".slidelist");

  const animateSlide = () => {
    setTimeout(() => {
      slideList.style.marginLeft = "-1200px";
      setTimeout(() => {
        slideList.style.marginLeft = "-2400px";
        setTimeout(() => {
          slideList.style.marginLeft = "0px";
          setTimeout(animateSlide, 3000);
        }, 3000);
      }, 3000);
    }, 3000);
  }

  setTimeout(animateSlide, 1000);
}

slideShow();
