// Navi
const liTags = document.querySelectorAll(".navi > li");
liTags.forEach((li) => {
  li.addEventListener("mouseover", () => {
    const submenu = li.querySelector(".submenu");
    submenu.style.display = "block";
  });

  li.addEventListener("mouseout", () => {
    const submenu = li.querySelector(".submenu");
    submenu.style.display = "none";
  });
});

// Slide
const slides = document.querySelectorAll(".imgslide a");

// 첫번째 슬라이드 부터 출력될 수 있도록 하는 반복문
slides.forEach((slide, index) => {
  if(index > 0) {
    slide.style.display = "none";
  };
});

let currentIndex = 0;
setInterval(() => {
  slides[currentIndex].style.opacity = 0;
  slides[currentIndex].style.transition = "opacity 1s";

  currentIndex = (currentIndex + 1) % slides.length;

  slides[currentIndex].style.display = "block";
  slides[currentIndex].style.opacity = 0;
  slides[currentIndex].style.transition = "opacity 1s";

  setTimeout(() => {
    slides[currentIndex].style.opacity = 1;
  }, 10);
}, 3000);

// Modal

// 1.공지사항 내 첫번째 게시글을 클릭하면 모달창이 나타난다.

// 1_1.웹브라우저에게 공지사항 내 첫번째 게시글이 어디에있는지 알려줘야 한다.

// 1_2.첫번째 게시글이 클릭되었다는 사실을 알려줘야한다.

// 1_3.웹브라우저에게 모달창이 어디에있는지 알려줘야한다.

// 1_4.모달창의 원래 display속성을 block으로 바꿔주도록한다.

// 2.모달창 내 닫기 버튼을 클릭하면 모달창이 사라진다.

// 2_1.모달창 내 닫기 버튼을 웹 브라우저에게 알려준다.

// 2_2.닫기 버튼을 클릭되었다는 사실을 알려준다.

// 2_3.닫기 버튼이 클릭되면, 모달창의 원래 display속성인 none으로 바꾼다.

const noticeList = document.querySelector(".notice li:first-child");
const modal = document.querySelector("#modal");
const btn = document.querySelector(".btn");

noticeList.addEventListener("click", () => {
  modal.classList.add("active");
});

btn.addEventListener("click", () => {
  modal.classList.remove("active");
});

// DOM => Document Object Model
// 객체 => 속성 // 메서드
// JS => 객체 지향 언어!!
// 객체